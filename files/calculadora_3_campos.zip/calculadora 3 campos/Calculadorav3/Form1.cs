﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadorav3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            blankField1.Text = "0";
            blankField2.Text = "0";
            blankfield3.Text = "0";
            if (protecao.Checked == false)
            {
                seno.Enabled = false;
                cosseno.Enabled = false;
                seno.Enabled = false;
                cosseno.Enabled = false;
                tangente.Enabled = false;
                arcoSeno.Enabled = false;
                aCos.Enabled = false;
                aTan.Enabled = false;
                square2.Enabled = false;
                log.Enabled = false;
                baseEuller.Enabled = false;
                euller.Enabled = false;
                numeroGold.Enabled = false;
                oneX.Enabled = false;
                Fatorial.Enabled = false;
              
                log10.Enabled = false;
                square.Enabled = false;
                // blankfield3.Enabled = false;
                rootSquare.Enabled = false;
            }
            MessageBox.Show("Por favor, habilite e desabilite a proteção");
        }

        Boolean ponto_iniciado = false;
        double val1, val2, res;
  



        public void clearField(Boolean clear_operator = false)
        {
            if (on_off.Checked == true)
            {
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
            else
            {
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
          
            ponto_iniciado = false;
            
             if (on_off.Checked == true && protecao.Checked == false)
             {
                 blankField1.Text = "0";
             }
        }

        private void blankField_TextChanged(object sender, EventArgs e)
        {

        }

        private void clear_Click(object sender, EventArgs e)
        {

            clearField(true);
        }



        private void plus_Click(object sender, EventArgs e)//soma
        {
            try{
            val1 = double.Parse(blankField1.Text);
            val2 = double.Parse(blankField2.Text);
            blankfield3.Text = (val1 + val2).ToString();
             }
            catch
            {
                MessageBox.Show("Erro");
                MessageBox.Show("Não é possivel fazer operações de letras com números!!");
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }

        }

        private void subtract_Click(object sender, EventArgs e)//subtrair
        {
           try{
            val1 = double.Parse(blankField1.Text);
            val2 = double.Parse(blankField2.Text);
            res = val1 - val2;
            blankfield3.Text = res.ToString();
             }
            catch
            {
                MessageBox.Show("Erro");
                MessageBox.Show("Não é possivel fazer operações de letras com números!!");
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void multiply_Click(object sender, EventArgs e)//multiplicar
        {
            try{
            val1 = double.Parse(blankField1.Text);
            val2 = double.Parse(blankField2.Text);
            res = val1 * val2;
            blankfield3.Text = res.ToString();
             }
            catch
            {
                MessageBox.Show("Erro");
                MessageBox.Show("Não é possivel fazer operações de letras com números!!");
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void slice_Click(object sender, EventArgs e)//dividir
        {
            try{
            val1 = double.Parse(blankField1.Text);
            val2 = double.Parse(blankField2.Text);
            blankfield3.Text = (val1 / val2).ToString();
             }
            catch
            {
                MessageBox.Show("Erro");
                MessageBox.Show("Não é possivel fazer operações de letras com números!!");
                blankField1.Text = "0";
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }

        }

        private void dot_Click(object sender, EventArgs e)
        {
            if (ponto_iniciado == false)
            {
                blankField1.Text = blankField1.Text + ",";
                ponto_iniciado = true;
            }

        }






        private void seno_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "seno";
                val2 = double.Parse(blankField2.Text);
                res = Math.Sin(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }



        }

        private void cosseno_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Cosseno";
                val2 = double.Parse(blankField2.Text);
                res = Math.Cos(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void rootSquare_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Raiz";
                val1 = double.Parse(blankField2.Text);
                res = Math.Sqrt(val1);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void Porcentagem_Click(object sender, EventArgs e)
        {
            try
            {
                val1 = double.Parse(blankField1.Text);
                val2 = double.Parse(blankField2.Text);
                blankfield3.Text = ((val1 * val2) / 100).ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }

        }

        private void potencia_Click(object sender, EventArgs e)
        {
            try
            {
                val1 = double.Parse(blankField1.Text);
                val2 = double.Parse(blankField2.Text);
                blankfield3.Text = Math.Pow(val1, val2).ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void tangente_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Tangente";
                val2 = double.Parse(blankField2.Text);
                res = Math.Tan(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void log10_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Log10";
                val2 = double.Parse(blankField2.Text);
                res = Math.Log10(val2);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void log_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Log";
                val2 = double.Parse(blankField2.Text);
                res = Math.Log(val2);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }

        private void arcoSeno_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "ArcoSeno";
                val2 = double.Parse(blankField2.Text);
                res = Math.Asin(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }

        private void aCos_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "ArcoCosseno";
                val2 = double.Parse(blankField2.Text);
                res = Math.Acos(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }

        private void aTan_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "ArcoTangente";
                val2 = double.Parse(blankField2.Text);
                res = Math.Atan(val2 * 3.1416 / 180);
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }

        private void Fatorial_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "Fatorial";
                int numero;
                numero = int.Parse(blankField2.Text);
                int fatorial;
                fatorial = numero;
                blankfield3.Text = "!";
                for (int i = numero - 1; i > 1; i--)
                {
                    fatorial *= i;
                }
                blankfield3.Text = fatorial.ToString();
            }
            catch
            {
                MessageBox.Show("ERRO! número com muitas casas");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }
        private void oneX_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "1/x";
                blankfield3.Text = (1 / double.Parse(blankField2.Text)).ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }
        private void pi_Click(object sender, EventArgs e)
        {
            
            
            if (protecao.Checked == false)
            {
               // if (blankField1.Text == "0" && blankField2.Text == "0")
               // { blankField1.Text = Math.PI.ToString(); }
                if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = Math.PI.ToString();
                }
                if (val2 == 0 && val1 == 0)
                {
                    blankField1.Text = Math.PI.ToString();

                }
                else if (val1 >= 0 && val2 == 0)
                {
                    blankField2.Text = Math.PI.ToString();
                }
                else if (val2 >= 0 && val1 == 0)
                {
                    blankField1.Text = Math.PI.ToString();
                }
              

            


            }
            else
            {
                if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = Math.PI.ToString();
                }
                if (val2 == 0 && val1 > 0)
                {
                    blankField2.Text = Math.PI.ToString();

                }

                if (blankField1.Text == "0" && blankField2.Text == "0")
                {
                    blankField1.Text = Math.PI.ToString();
                }

               
            }


            if (protecao.Checked == true && on_off.Checked == true)
            {
                if (val1 == 0)
                {
                    blankField2.Text = Math.PI.ToString();
                }
                else if (val1 > 0)
                {
                    blankField2.Text = Math.PI.ToString();
                }
            }



        }



        private void raisQlr_Click(object sender, EventArgs e)
        {

            try
            {
                val1 = double.Parse(blankField1.Text);
                val2 = double.Parse(blankField2.Text);
                blankfield3.Text = Math.Pow(val2, (1 / val1)).ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";

            }
        }
        private void euller_Click(object sender, EventArgs e)
        {
            if (protecao.Checked == false)
            {

                if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = Math.E.ToString();
                }
                if (val2 == 0 && val1 == 0)
                {
                    blankField1.Text = Math.E.ToString();

                }
                else if (val1 >= 0 && val2 == 0)
                {
                    blankField2.Text = Math.E.ToString();
                }
                else if (val2 >= 0 && val1 == 0)
                {
                    blankField1.Text = Math.E.ToString();
                }
               /* else if (val2 > 0 && blankField1.Text == "0")
                {
                    blankField1.Text = Math.E.ToString();
                }*/
                


            }
            else//proteção ativa
            {

               
                if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = Math.E.ToString();
                }
                if (val2 == 0 && val1 > 0)
                {
                    blankField2.Text = Math.E.ToString();

                }

                if (blankField1.Text == "0" && blankField2.Text == "0")
                {
                    blankField1.Text = Math.E.ToString();
                }
                
             

            }


            if (protecao.Checked == true && on_off.Checked == true)//cientifico
            {
                if (val2 == 0)
                {
                    blankField2.Text = Math.E.ToString();
                }
                else if (val2 > 0)
                {
                    blankField2.Text = Math.E.ToString();
                }
            }



        }




        private void baseEuller_Click(object sender, EventArgs e)
        {
            try
            {
                val2 = double.Parse(blankField2.Text);
                blankfield3.Text = Math.Pow(Math.E, val2).ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }

        private void numeroGold_Click(object sender, EventArgs e)
        {
           
            if (protecao.Checked == false)
            {

                if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = 1.61803398875.ToString();
                }
                if (val2 == 0 && val1 == 0)
                {
                    blankField1.Text = 1.61803398875.ToString();

                }
                else if (val1 >= 0 && val2 == 0)
                {
                    blankField2.Text = 1.61803398875.ToString();
                }
                else if (val2 >= 0 && val1 == 0)
                {
                    blankField1.Text = 1.61803398875.ToString();
                }
                else if (val2 > 0 && blankField1.Text == "0")
                {
                    blankField1.Text = 1.61803398875.ToString();
                }

            }
            else//proteção ativa
            {
             if (val1 == 0 && val2 > 0)
                {
                    blankField1.Text = 1.61803398875.ToString();
                }
                if (val2 == 0 && val1 > 0)
                {
                    blankField2.Text = 1.61803398875.ToString();

                }

                if (blankField1.Text == "0" && blankField2.Text == "0")
                {
                    blankField1.Text = 1.61803398875.ToString();
                }
            }


            if (protecao.Checked == true && on_off.Checked == true)//cientifico
            {
                if (val1 == 0)
                {
                    blankField2.Text = 1.61803398875.ToString();
                }
                else if (val1 > 0)
                {
                    blankField2.Text = 1.61803398875.ToString();
                }
            }



        }
            
            
        

        private void log2_Click(object sender, EventArgs e)
        {
        }

        private void square_Click(object sender, EventArgs e)
        {
            try
            {
                blankField1.Text = "X²";
                val2 = double.Parse(blankField2.Text);
                res = val2 * val2;
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }
        private void on_off_CheckedChanged(object sender, EventArgs e)
        {
            if (protecao.Checked == true)
            {
                if (on_off.Checked == true)
                {
                    clearField();
                    seno.Enabled = true;
                    cosseno.Enabled = true;
                    tangente.Enabled = true;
                    arcoSeno.Enabled = true;
                    aCos.Enabled = true;
                    aTan.Enabled = true;
                    square2.Enabled = true;
                    log.Enabled = true;
                    oneX.Enabled = true;
                    Fatorial.Enabled = true;
                  
                    log10.Enabled = true;
                    square.Enabled = true;
                    rootSquare.Enabled = true;
                }
                else
                {

                    seno.Enabled = false;
                    cosseno.Enabled = false;
                    tangente.Enabled = false;
                    arcoSeno.Enabled = false;
                    aCos.Enabled = false;
                    aTan.Enabled = false;
                    square2.Enabled = false;
                    log.Enabled = false;
                    oneX.Enabled = false;
                    Fatorial.Enabled = false;
                   
                    log10.Enabled = false;
                    square.Enabled = false;
                    rootSquare.Enabled = false;
                }
                if (on_off.Checked == false)
                {
                    clearField();
                    plus.Enabled = true;
                    multiply.Enabled = true;
                    slice.Enabled = true;
                    subtract.Enabled = true;
                    raisQlr.Enabled = true;
                    potencia.Enabled = true;
                    Porcentagem.Enabled = true;
                    blankField1.Enabled = true;
                    blankField1.Text = "";
                    clearField();
                }
                else
                {
                    plus.Enabled = false;
                    multiply.Enabled = false;
                    slice.Enabled = false;
                    subtract.Enabled = false;
                    raisQlr.Enabled = false;
                    potencia.Enabled = false;
                    Porcentagem.Enabled = false;
                    blankField1.Enabled = false;
                    blankField1.Text = "Científico";
                }
            }
            else
            {
                seno.Enabled = true;
                cosseno.Enabled = true;
                tangente.Enabled = true;
                arcoSeno.Enabled = true;
                aCos.Enabled = true;
                aTan.Enabled = true;
                square2.Enabled = true;
                log.Enabled = true;
                oneX.Enabled = true;
                Fatorial.Enabled = true;
               
                log10.Enabled = true;
                square.Enabled = true;
                rootSquare.Enabled = true;
                plus.Enabled = true;
                multiply.Enabled = true;
                slice.Enabled = true;
                subtract.Enabled = true;
                raisQlr.Enabled = true;
                potencia.Enabled = true;
                Porcentagem.Enabled = true;
                blankField1.Enabled = true;

            }
        }


        private void button1_Click(object sender, EventArgs e) { }




        private void blankfield3_TextChanged(object sender, EventArgs e) { blankfield3.Enabled = false; }

        private void protecao_CheckedChanged(object sender, EventArgs e)
        {

            if (protecao.Checked == true)
            {
                clearField();
                if (on_off.Checked == true)
                {

                    seno.Enabled = true;
                    cosseno.Enabled = true;
                    tangente.Enabled = true;
                    arcoSeno.Enabled = true;
                    aCos.Enabled = true;
                    aTan.Enabled = true;
                    square2.Enabled = true;
                    log.Enabled = true;
                    oneX.Enabled = true;
                    Fatorial.Enabled = true;
                  
                    log10.Enabled = true;
                    square.Enabled = true;
                    rootSquare.Enabled = true;
                }
                else
                {

                    seno.Enabled = false;
                    cosseno.Enabled = false;
                    tangente.Enabled = false;
                    arcoSeno.Enabled = false;
                    aCos.Enabled = false;
                    aTan.Enabled = false;
                    square2.Enabled = false;
                    log.Enabled = false;
                    oneX.Enabled = false;
                    Fatorial.Enabled = false;
                    
                    log10.Enabled = false;
                    square.Enabled = false;
                    rootSquare.Enabled = false;
                }
                if (on_off.Checked == false)
                {

                    clearField();
                    plus.Enabled = true;
                    multiply.Enabled = true;
                    slice.Enabled = true;
                    subtract.Enabled = true;
                    raisQlr.Enabled = true;
                    potencia.Enabled = true;
                    Porcentagem.Enabled = true;
                    blankField1.Enabled = true;
                    blankField1.Text = "";
                    clearField();
                }
                else
                {
                    plus.Enabled = false;
                    multiply.Enabled = false;
                    slice.Enabled = false;
                    subtract.Enabled = false;
                    blankField1.Enabled = false;
                    raisQlr.Enabled = false;
                    potencia.Enabled = false;
                    Porcentagem.Enabled = false;
                    blankField1.Text = "Científico";
                }
            }
            else
            {
                seno.Enabled = true;
                cosseno.Enabled = true;
                tangente.Enabled = true;
                arcoSeno.Enabled = true;
                aCos.Enabled = true;
                aTan.Enabled = true;
                square2.Enabled = true;
                log.Enabled = true;
                oneX.Enabled = true;
                Fatorial.Enabled = true;
               
                log10.Enabled = true;
                square.Enabled = true;
                rootSquare.Enabled = true;
                plus.Enabled = true;
                multiply.Enabled = true;
                slice.Enabled = true;
                subtract.Enabled = true;
                blankField1.Enabled = true;
                raisQlr.Enabled = true;
                potencia.Enabled = true;
                Porcentagem.Enabled = true;

            }
        }

        private void limpar1_Click(object sender, EventArgs e)
        {

            if (on_off.Checked == true)
            {

            }
               
            else
            { blankField1.Text = "0"; }
             if (on_off.Checked == true && protecao.Checked == false)
             { blankField1.Text = "0"; }

        }

        private void limpar2_Click(object sender, EventArgs e)
        {
            blankField2.Text = "0";
        }

        private void limpar3_Click(object sender, EventArgs e)
        {
            blankfield3.Text = "0";
        }

        private void Help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Check box on/off- Habilita a parte científica da calculadora\nProteção- Ativa ou desativa a proteção da calculadora\n A utilização da tecla '.' dedica-se apenas ao primeiro campo valor 1 \n\nATENÇÃO\n A desativação da proteção pode causar problemas na execução da calculadora");
        }

        private void square2_Click(object sender, EventArgs e)
        {
             try
            {
                blankField1.Text = "X²";
                val2 = double.Parse(blankField2.Text);
                res = val2 * val2*val2;
                blankfield3.Text = res.ToString();
            }
            catch
            {
                MessageBox.Show("Erro");
                blankField2.Text = "0";
                blankfield3.Text = "0";
            }
        }

        
        



    }      
        
}
