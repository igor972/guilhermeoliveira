﻿namespace Calculadorav3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.subtract = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.slice = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.dot = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.blankField1 = new System.Windows.Forms.TextBox();
            this.tangente = new System.Windows.Forms.Button();
            this.potencia = new System.Windows.Forms.Button();
            this.Porcentagem = new System.Windows.Forms.Button();
            this.aCos = new System.Windows.Forms.Button();
            this.arcoSeno = new System.Windows.Forms.Button();
            this.cosseno = new System.Windows.Forms.Button();
            this.log10 = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Button();
            this.raisQlr = new System.Windows.Forms.Button();
            this.Fatorial = new System.Windows.Forms.Button();
            this.aTan = new System.Windows.Forms.Button();
            this.seno = new System.Windows.Forms.Button();
            this.rootSquare = new System.Windows.Forms.Button();
            this.oneX = new System.Windows.Forms.Button();
            this.pi = new System.Windows.Forms.Button();
            this.euller = new System.Windows.Forms.Button();
            this.baseEuller = new System.Windows.Forms.Button();
            this.numeroGold = new System.Windows.Forms.Button();
            this.square = new System.Windows.Forms.Button();
            this.Valor1 = new System.Windows.Forms.Label();
            this.Valor2 = new System.Windows.Forms.Label();
            this.resultado = new System.Windows.Forms.Label();
            this.blankField2 = new System.Windows.Forms.TextBox();
            this.on_off = new System.Windows.Forms.CheckBox();
            this.square2 = new System.Windows.Forms.Button();
            this.blankfield3 = new System.Windows.Forms.TextBox();
            this.protecao = new System.Windows.Forms.CheckBox();
            this.limpar1 = new System.Windows.Forms.Button();
            this.limpar2 = new System.Windows.Forms.Button();
            this.limpar3 = new System.Windows.Forms.Button();
            this.Help = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // subtract
            // 
            this.subtract.Cursor = System.Windows.Forms.Cursors.Hand;
            this.subtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subtract.ForeColor = System.Drawing.Color.Black;
            this.subtract.Location = new System.Drawing.Point(280, 236);
            this.subtract.Name = "subtract";
            this.subtract.Size = new System.Drawing.Size(40, 26);
            this.subtract.TabIndex = 13;
            this.subtract.Text = "-";
            this.subtract.UseVisualStyleBackColor = true;
            this.subtract.Click += new System.EventHandler(this.subtract_Click);
            // 
            // multiply
            // 
            this.multiply.Cursor = System.Windows.Forms.Cursors.Hand;
            this.multiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiply.ForeColor = System.Drawing.Color.Black;
            this.multiply.Location = new System.Drawing.Point(234, 236);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(40, 26);
            this.multiply.TabIndex = 12;
            this.multiply.Text = "X";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // slice
            // 
            this.slice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.slice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slice.ForeColor = System.Drawing.Color.Black;
            this.slice.Location = new System.Drawing.Point(280, 204);
            this.slice.Name = "slice";
            this.slice.Size = new System.Drawing.Size(40, 26);
            this.slice.TabIndex = 11;
            this.slice.Text = "/";
            this.slice.UseVisualStyleBackColor = true;
            this.slice.Click += new System.EventHandler(this.slice_Click);
            // 
            // plus
            // 
            this.plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plus.ForeColor = System.Drawing.Color.Black;
            this.plus.Location = new System.Drawing.Point(234, 201);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(40, 26);
            this.plus.TabIndex = 14;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // dot
            // 
            this.dot.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dot.ForeColor = System.Drawing.Color.Black;
            this.dot.Location = new System.Drawing.Point(280, 327);
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(40, 26);
            this.dot.TabIndex = 16;
            this.dot.Text = ",";
            this.dot.UseVisualStyleBackColor = true;
            this.dot.Click += new System.EventHandler(this.dot_Click);
            // 
            // clear
            // 
            this.clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.ForeColor = System.Drawing.Color.Black;
            this.clear.Location = new System.Drawing.Point(234, 172);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(76, 26);
            this.clear.TabIndex = 19;
            this.clear.Text = "Clear All";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // blankField1
            // 
            this.blankField1.Location = new System.Drawing.Point(7, 66);
            this.blankField1.Multiline = true;
            this.blankField1.Name = "blankField1";
            this.blankField1.Size = new System.Drawing.Size(86, 35);
            this.blankField1.TabIndex = 21;
            this.blankField1.TextChanged += new System.EventHandler(this.blankField_TextChanged);
            // 
            // tangente
            // 
            this.tangente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tangente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tangente.ForeColor = System.Drawing.Color.Black;
            this.tangente.Location = new System.Drawing.Point(121, 172);
            this.tangente.Name = "tangente";
            this.tangente.Size = new System.Drawing.Size(55, 26);
            this.tangente.TabIndex = 27;
            this.tangente.Text = "Tan";
            this.tangente.UseVisualStyleBackColor = true;
            this.tangente.Click += new System.EventHandler(this.tangente_Click);
            // 
            // potencia
            // 
            this.potencia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.potencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.potencia.ForeColor = System.Drawing.Color.Black;
            this.potencia.Location = new System.Drawing.Point(280, 266);
            this.potencia.Name = "potencia";
            this.potencia.Size = new System.Drawing.Size(40, 26);
            this.potencia.TabIndex = 26;
            this.potencia.Text = "yˣ";
            this.potencia.UseVisualStyleBackColor = true;
            this.potencia.Click += new System.EventHandler(this.potencia_Click);
            // 
            // Porcentagem
            // 
            this.Porcentagem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Porcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Porcentagem.ForeColor = System.Drawing.Color.Black;
            this.Porcentagem.Location = new System.Drawing.Point(234, 299);
            this.Porcentagem.Name = "Porcentagem";
            this.Porcentagem.Size = new System.Drawing.Size(40, 26);
            this.Porcentagem.TabIndex = 24;
            this.Porcentagem.Text = "%";
            this.Porcentagem.UseVisualStyleBackColor = true;
            this.Porcentagem.Click += new System.EventHandler(this.Porcentagem_Click);
            // 
            // aCos
            // 
            this.aCos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aCos.ForeColor = System.Drawing.Color.Black;
            this.aCos.Location = new System.Drawing.Point(60, 210);
            this.aCos.Name = "aCos";
            this.aCos.Size = new System.Drawing.Size(55, 26);
            this.aCos.TabIndex = 32;
            this.aCos.Text = "Acos";
            this.aCos.UseVisualStyleBackColor = true;
            this.aCos.Click += new System.EventHandler(this.aCos_Click);
            // 
            // arcoSeno
            // 
            this.arcoSeno.Cursor = System.Windows.Forms.Cursors.Hand;
            this.arcoSeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arcoSeno.ForeColor = System.Drawing.Color.Black;
            this.arcoSeno.Location = new System.Drawing.Point(-1, 210);
            this.arcoSeno.Name = "arcoSeno";
            this.arcoSeno.Size = new System.Drawing.Size(55, 26);
            this.arcoSeno.TabIndex = 30;
            this.arcoSeno.Text = "Asen";
            this.arcoSeno.UseVisualStyleBackColor = true;
            this.arcoSeno.Click += new System.EventHandler(this.arcoSeno_Click);
            // 
            // cosseno
            // 
            this.cosseno.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cosseno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cosseno.ForeColor = System.Drawing.Color.Black;
            this.cosseno.Location = new System.Drawing.Point(60, 173);
            this.cosseno.Name = "cosseno";
            this.cosseno.Size = new System.Drawing.Size(55, 26);
            this.cosseno.TabIndex = 29;
            this.cosseno.Text = "Cos";
            this.cosseno.UseVisualStyleBackColor = true;
            this.cosseno.Click += new System.EventHandler(this.cosseno_Click);
            // 
            // log10
            // 
            this.log10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.log10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log10.ForeColor = System.Drawing.Color.Black;
            this.log10.Location = new System.Drawing.Point(60, 298);
            this.log10.Name = "log10";
            this.log10.Size = new System.Drawing.Size(55, 26);
            this.log10.TabIndex = 34;
            this.log10.Text = "Log10";
            this.log10.UseVisualStyleBackColor = true;
            this.log10.Click += new System.EventHandler(this.log10_Click);
            // 
            // log
            // 
            this.log.Cursor = System.Windows.Forms.Cursors.Hand;
            this.log.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log.ForeColor = System.Drawing.Color.Black;
            this.log.Location = new System.Drawing.Point(-1, 298);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(55, 26);
            this.log.TabIndex = 33;
            this.log.Text = "Log";
            this.log.UseVisualStyleBackColor = true;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // raisQlr
            // 
            this.raisQlr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.raisQlr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raisQlr.ForeColor = System.Drawing.Color.Black;
            this.raisQlr.Location = new System.Drawing.Point(280, 298);
            this.raisQlr.Name = "raisQlr";
            this.raisQlr.Size = new System.Drawing.Size(62, 26);
            this.raisQlr.TabIndex = 36;
            this.raisQlr.Text = "qlqr√";
            this.raisQlr.UseVisualStyleBackColor = true;
            this.raisQlr.Click += new System.EventHandler(this.raisQlr_Click);
            // 
            // Fatorial
            // 
            this.Fatorial.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Fatorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fatorial.ForeColor = System.Drawing.Color.Black;
            this.Fatorial.Location = new System.Drawing.Point(-1, 266);
            this.Fatorial.Name = "Fatorial";
            this.Fatorial.Size = new System.Drawing.Size(116, 26);
            this.Fatorial.TabIndex = 37;
            this.Fatorial.Text = "Fatorial";
            this.Fatorial.UseVisualStyleBackColor = true;
            this.Fatorial.Click += new System.EventHandler(this.Fatorial_Click);
            // 
            // aTan
            // 
            this.aTan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aTan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aTan.ForeColor = System.Drawing.Color.Black;
            this.aTan.Location = new System.Drawing.Point(121, 210);
            this.aTan.Name = "aTan";
            this.aTan.Size = new System.Drawing.Size(55, 26);
            this.aTan.TabIndex = 42;
            this.aTan.Text = "Atan";
            this.aTan.UseVisualStyleBackColor = true;
            this.aTan.Click += new System.EventHandler(this.aTan_Click);
            // 
            // seno
            // 
            this.seno.Cursor = System.Windows.Forms.Cursors.Hand;
            this.seno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seno.ForeColor = System.Drawing.Color.Black;
            this.seno.Location = new System.Drawing.Point(-1, 173);
            this.seno.Name = "seno";
            this.seno.Size = new System.Drawing.Size(55, 26);
            this.seno.TabIndex = 43;
            this.seno.Text = "Seno";
            this.seno.UseVisualStyleBackColor = true;
            this.seno.Click += new System.EventHandler(this.seno_Click);
            // 
            // rootSquare
            // 
            this.rootSquare.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rootSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rootSquare.ForeColor = System.Drawing.Color.Black;
            this.rootSquare.Location = new System.Drawing.Point(234, 268);
            this.rootSquare.Name = "rootSquare";
            this.rootSquare.Size = new System.Drawing.Size(40, 26);
            this.rootSquare.TabIndex = 44;
            this.rootSquare.Text = "√";
            this.rootSquare.UseVisualStyleBackColor = true;
            this.rootSquare.Click += new System.EventHandler(this.rootSquare_Click);
            // 
            // oneX
            // 
            this.oneX.Cursor = System.Windows.Forms.Cursors.Hand;
            this.oneX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneX.ForeColor = System.Drawing.Color.Black;
            this.oneX.Location = new System.Drawing.Point(121, 239);
            this.oneX.Name = "oneX";
            this.oneX.Size = new System.Drawing.Size(55, 26);
            this.oneX.TabIndex = 46;
            this.oneX.Text = "1/x";
            this.oneX.UseVisualStyleBackColor = true;
            this.oneX.Click += new System.EventHandler(this.oneX_Click);
            // 
            // pi
            // 
            this.pi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pi.Font = new System.Drawing.Font("Sitka Subheading", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pi.ForeColor = System.Drawing.Color.Black;
            this.pi.Location = new System.Drawing.Point(234, 328);
            this.pi.Name = "pi";
            this.pi.Size = new System.Drawing.Size(40, 26);
            this.pi.TabIndex = 48;
            this.pi.Text = "π";
            this.pi.UseVisualStyleBackColor = true;
            this.pi.Click += new System.EventHandler(this.pi_Click);
            // 
            // euller
            // 
            this.euller.Cursor = System.Windows.Forms.Cursors.Hand;
            this.euller.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.euller.ForeColor = System.Drawing.Color.Black;
            this.euller.Location = new System.Drawing.Point(60, 326);
            this.euller.Name = "euller";
            this.euller.Size = new System.Drawing.Size(40, 26);
            this.euller.TabIndex = 49;
            this.euller.Text = "e";
            this.euller.UseVisualStyleBackColor = true;
            this.euller.Click += new System.EventHandler(this.euller_Click);
            // 
            // baseEuller
            // 
            this.baseEuller.Cursor = System.Windows.Forms.Cursors.Hand;
            this.baseEuller.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baseEuller.ForeColor = System.Drawing.Color.Black;
            this.baseEuller.Location = new System.Drawing.Point(-1, 327);
            this.baseEuller.Name = "baseEuller";
            this.baseEuller.Size = new System.Drawing.Size(40, 26);
            this.baseEuller.TabIndex = 50;
            this.baseEuller.Text = "eˣ";
            this.baseEuller.UseVisualStyleBackColor = true;
            this.baseEuller.Click += new System.EventHandler(this.baseEuller_Click);
            // 
            // numeroGold
            // 
            this.numeroGold.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("numeroGold.BackgroundImage")));
            this.numeroGold.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.numeroGold.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeroGold.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numeroGold.ForeColor = System.Drawing.Color.Black;
            this.numeroGold.Location = new System.Drawing.Point(121, 324);
            this.numeroGold.Name = "numeroGold";
            this.numeroGold.Size = new System.Drawing.Size(40, 28);
            this.numeroGold.TabIndex = 52;
            this.numeroGold.UseVisualStyleBackColor = true;
            this.numeroGold.Click += new System.EventHandler(this.numeroGold_Click);
            // 
            // square
            // 
            this.square.Cursor = System.Windows.Forms.Cursors.Hand;
            this.square.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square.ForeColor = System.Drawing.Color.Black;
            this.square.Location = new System.Drawing.Point(-1, 239);
            this.square.Name = "square";
            this.square.Size = new System.Drawing.Size(55, 26);
            this.square.TabIndex = 53;
            this.square.Text = "x²";
            this.square.UseVisualStyleBackColor = true;
            this.square.Click += new System.EventHandler(this.square_Click);
            // 
            // Valor1
            // 
            this.Valor1.AutoSize = true;
            this.Valor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valor1.Location = new System.Drawing.Point(24, 38);
            this.Valor1.Name = "Valor1";
            this.Valor1.Size = new System.Drawing.Size(74, 25);
            this.Valor1.TabIndex = 56;
            this.Valor1.Text = "Valor1";
            // 
            // Valor2
            // 
            this.Valor2.AutoSize = true;
            this.Valor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valor2.Location = new System.Drawing.Point(129, 38);
            this.Valor2.Name = "Valor2";
            this.Valor2.Size = new System.Drawing.Size(74, 25);
            this.Valor2.TabIndex = 57;
            this.Valor2.Text = "Valor2";
            // 
            // resultado
            // 
            this.resultado.AutoSize = true;
            this.resultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultado.Location = new System.Drawing.Point(234, 38);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(109, 25);
            this.resultado.TabIndex = 58;
            this.resultado.Text = "Resultado";
            // 
            // blankField2
            // 
            this.blankField2.Location = new System.Drawing.Point(129, 66);
            this.blankField2.Multiline = true;
            this.blankField2.Name = "blankField2";
            this.blankField2.Size = new System.Drawing.Size(86, 35);
            this.blankField2.TabIndex = 59;
            // 
            // on_off
            // 
            this.on_off.AutoSize = true;
            this.on_off.Location = new System.Drawing.Point(7, 150);
            this.on_off.Name = "on_off";
            this.on_off.Size = new System.Drawing.Size(59, 17);
            this.on_off.TabIndex = 61;
            this.on_off.Text = "On/Off";
            this.on_off.UseVisualStyleBackColor = true;
            this.on_off.CheckedChanged += new System.EventHandler(this.on_off_CheckedChanged);
            // 
            // square2
            // 
            this.square2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.square2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square2.ForeColor = System.Drawing.Color.Black;
            this.square2.Location = new System.Drawing.Point(60, 239);
            this.square2.Name = "square2";
            this.square2.Size = new System.Drawing.Size(55, 26);
            this.square2.TabIndex = 62;
            this.square2.Text = "x³";
            this.square2.UseVisualStyleBackColor = true;
            this.square2.Click += new System.EventHandler(this.square2_Click);
            // 
            // blankfield3
            // 
            this.blankfield3.Location = new System.Drawing.Point(234, 66);
            this.blankfield3.Multiline = true;
            this.blankfield3.Name = "blankfield3";
            this.blankfield3.Size = new System.Drawing.Size(156, 35);
            this.blankfield3.TabIndex = 55;
            this.blankfield3.TextChanged += new System.EventHandler(this.blankfield3_TextChanged);
            // 
            // protecao
            // 
            this.protecao.AutoSize = true;
            this.protecao.Checked = true;
            this.protecao.CheckState = System.Windows.Forms.CheckState.Checked;
            this.protecao.Location = new System.Drawing.Point(234, 149);
            this.protecao.Name = "protecao";
            this.protecao.Size = new System.Drawing.Size(69, 17);
            this.protecao.TabIndex = 63;
            this.protecao.Text = "Proteção";
            this.protecao.UseVisualStyleBackColor = true;
            this.protecao.CheckedChanged += new System.EventHandler(this.protecao_CheckedChanged);
            // 
            // limpar1
            // 
            this.limpar1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.limpar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpar1.ForeColor = System.Drawing.Color.Black;
            this.limpar1.Location = new System.Drawing.Point(6, 107);
            this.limpar1.Name = "limpar1";
            this.limpar1.Size = new System.Drawing.Size(76, 26);
            this.limpar1.TabIndex = 64;
            this.limpar1.Text = "Limpar";
            this.limpar1.UseVisualStyleBackColor = true;
            this.limpar1.Click += new System.EventHandler(this.limpar1_Click);
            // 
            // limpar2
            // 
            this.limpar2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.limpar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpar2.ForeColor = System.Drawing.Color.Black;
            this.limpar2.Location = new System.Drawing.Point(129, 107);
            this.limpar2.Name = "limpar2";
            this.limpar2.Size = new System.Drawing.Size(76, 26);
            this.limpar2.TabIndex = 65;
            this.limpar2.Text = "Limpar";
            this.limpar2.UseVisualStyleBackColor = true;
            this.limpar2.Click += new System.EventHandler(this.limpar2_Click);
            // 
            // limpar3
            // 
            this.limpar3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.limpar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpar3.ForeColor = System.Drawing.Color.Black;
            this.limpar3.Location = new System.Drawing.Point(234, 107);
            this.limpar3.Name = "limpar3";
            this.limpar3.Size = new System.Drawing.Size(76, 26);
            this.limpar3.TabIndex = 66;
            this.limpar3.Text = "Limpar";
            this.limpar3.UseVisualStyleBackColor = true;
            this.limpar3.Click += new System.EventHandler(this.limpar3_Click);
            // 
            // Help
            // 
            this.Help.Cursor = System.Windows.Forms.Cursors.Help;
            this.Help.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Help.ForeColor = System.Drawing.Color.Black;
            this.Help.Location = new System.Drawing.Point(129, 139);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(76, 26);
            this.Help.TabIndex = 67;
            this.Help.Text = "Ajuda";
            this.Help.UseVisualStyleBackColor = true;
            this.Help.Click += new System.EventHandler(this.Help_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(461, 378);
            this.Controls.Add(this.Help);
            this.Controls.Add(this.limpar3);
            this.Controls.Add(this.limpar2);
            this.Controls.Add(this.limpar1);
            this.Controls.Add(this.protecao);
            this.Controls.Add(this.square2);
            this.Controls.Add(this.on_off);
            this.Controls.Add(this.blankField2);
            this.Controls.Add(this.resultado);
            this.Controls.Add(this.Valor2);
            this.Controls.Add(this.Valor1);
            this.Controls.Add(this.blankfield3);
            this.Controls.Add(this.square);
            this.Controls.Add(this.numeroGold);
            this.Controls.Add(this.baseEuller);
            this.Controls.Add(this.euller);
            this.Controls.Add(this.pi);
            this.Controls.Add(this.oneX);
            this.Controls.Add(this.rootSquare);
            this.Controls.Add(this.seno);
            this.Controls.Add(this.aTan);
            this.Controls.Add(this.Fatorial);
            this.Controls.Add(this.raisQlr);
            this.Controls.Add(this.log10);
            this.Controls.Add(this.log);
            this.Controls.Add(this.aCos);
            this.Controls.Add(this.arcoSeno);
            this.Controls.Add(this.cosseno);
            this.Controls.Add(this.tangente);
            this.Controls.Add(this.potencia);
            this.Controls.Add(this.Porcentagem);
            this.Controls.Add(this.blankField1);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.dot);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.subtract);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.slice);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button subtract;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button slice;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button dot;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.TextBox blankField1;
        private System.Windows.Forms.Button tangente;
        private System.Windows.Forms.Button potencia;
        private System.Windows.Forms.Button Porcentagem;
        private System.Windows.Forms.Button aCos;
        private System.Windows.Forms.Button arcoSeno;
        private System.Windows.Forms.Button cosseno;
        private System.Windows.Forms.Button log10;
        private System.Windows.Forms.Button log;
        private System.Windows.Forms.Button raisQlr;
        private System.Windows.Forms.Button Fatorial;
        private System.Windows.Forms.Button aTan;
        private System.Windows.Forms.Button seno;
        private System.Windows.Forms.Button rootSquare;
        private System.Windows.Forms.Button oneX;
        private System.Windows.Forms.Button pi;
        private System.Windows.Forms.Button euller;
        private System.Windows.Forms.Button baseEuller;
        private System.Windows.Forms.Button numeroGold;
        private System.Windows.Forms.Button square;
        private System.Windows.Forms.Label Valor1;
        private System.Windows.Forms.Label Valor2;
        private System.Windows.Forms.Label resultado;
        private System.Windows.Forms.TextBox blankField2;
        private System.Windows.Forms.CheckBox on_off;
        private System.Windows.Forms.Button square2;
        private System.Windows.Forms.TextBox blankfield3;
        private System.Windows.Forms.CheckBox protecao;
        private System.Windows.Forms.Button limpar1;
        private System.Windows.Forms.Button limpar2;
        private System.Windows.Forms.Button limpar3;
        private System.Windows.Forms.Button Help;
    }
}

