// stdafx.cpp : arquivo de origem que inclui apenas as inclus�es padr�es
// jogo2.pch ser� o cabe�alho pr�-compilado
// stdafx.obj conter� as informa��es de tipo pr�-compiladas

#include "stdafx.h"

// TODO: referencie qualquer cabe�alho adicional necess�rio em STDAFX.H
// e n�o neste arquivo
