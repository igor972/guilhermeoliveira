#include "stdafx.h"
#include <stdlib.h>
#include <conio.h>
#include "ControlesDaTela.cpp"
#include <time.h>
#include <locale.h>
void main()
{
	int tecla = 0, move = 40, tela[80][25], x, y, score=0;
	setlocale(LC_ALL, "");
	Cor(0xF9);
	system("cls");

	DesligaCursor();
	VaiParaXY(move, 19);
	printf("   M   ");
	VaiParaXY(move, 20);
	printf("|_<=>_|");
	VaiParaXY(move, 21);
	printf("  <=> ");
	VaiParaXY(move, 22);
	printf(" o_W_o  ");
	//VaiParaXY(move, 23);
	VaiParaXY(1, 24); printf("Pontua��o %d", score);
	while (tecla != 27)
	{
		

	
		if (!_kbhit())
		{
			srand(time(NULL));
			x = rand() % 70 + 1;
			y = rand() % 10 + 3;
			tela[x][y] = 1;
			VaiParaXY(x,y);
			//Sleep(100);
			printf("%c", 05);
			
		
		}






		if (_kbhit())
		{


			tecla = _getch();
			VaiParaXY(move, 19);
			printf("  ");
			VaiParaXY(move, 20);
			printf("       ");
			VaiParaXY(move, 21);
			printf("       ");
			VaiParaXY(move, 22);
			printf("       ");
			//VaiParaXY(move, 23);

			if (tecla == 77)
			{
				if (move < 73)//77
				{
					move++;
				}
			}
			if (tecla == 75)//75
			{
				if (move > 0)
				{
					move--;
				}
			}
			Cor(0xF9);
			VaiParaXY(move, 19);
			printf("   M    ");
			VaiParaXY(move, 20);
			printf("|_<=>_|");
			VaiParaXY(move, 21);
			printf("  <=> ");
			VaiParaXY(move, 22);
			printf(" o_W_o  ");
			//VaiParaXY(move, 23);

			if (tecla == 32)
			{
				Beep(415, 200);
				for (int tiro = 18; tiro > 0; tiro--)
				{
					Cor(0xF4);
					VaiParaXY(move+3, tiro); printf("^^");
					Sleep(25);
					VaiParaXY(move+3, tiro); printf("  ");
					if (tela[move + 3][tiro] == 1 || tela[move + 4][tiro] == 1)
					{
						score++;
						tela[move+3][tiro] = 0;
						tela[move + 4][tiro] = 0;
						VaiParaXY(1,24);printf("Pontua��o %d", score);
					}
				}
			}
		}
	}
}
