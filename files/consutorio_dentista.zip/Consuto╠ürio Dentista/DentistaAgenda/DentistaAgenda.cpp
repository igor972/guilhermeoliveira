#include "stdafx.h"
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include "ControlesDaTela.cpp"
#include <locale.h>
struct test  //estrutura de dados
{
	char flag;
	char nome[60];
	char end[50];
	char tel[14];
	char cel[9];
	char conv[10];
	char nasc[8];
	char rg[10];
	char cpf[12];
	char email[45];
	int id;
	int dia;
	int mes;
	int ano;
	int dian;
	int mesn;
	int anon;
	int id2;
	int val_clareamento;
	int val_limpeza;
	int val_conta;
}agenda[4], aux, exclus�o, edita;
void cadastra();
void imprimi();
void ordena();
void cadastrar();
void salvar();
void carregar();
void consultar();
void excluir();
void fim();
void editar();
int menu();
void tela_abertura();

void main()
{
	tela_abertura();
	Sleep(2000);
	int v = 0, limpa;
	for (limpa = 0; limpa < 9; limpa++)
	{
		agenda[limpa].flag = '0';
	}
	while ((v <= 8) || (v >= 1))
	{
		v = menu();
		switch (v)
		{
		case 1:cadastra();
			break;
		case 2:imprimi();
			break;

		case 4:salvar();
			break;

		case 5:carregar();
			break;

		case 6:consultar();
			break;
		case 7:excluir();
			break;
		case 8: editar();
			break;
		case 3:fim();
			break;




		}
	}
}

void tela_abertura()
{
	int tela_linha, tela_coluna;
	DesligaCursor();
	system("cls");
	while (1)
	{
		int tela[25][81] =
		{
			{ 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
			{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			{ 4, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 4 },
			{ 4, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 4 },
			{ 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			{ 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
		};


		for (tela_linha = 0; tela_linha < 25; tela_linha++)
		{
			for (tela_coluna = 0; tela_coluna < 81; tela_coluna++)
			{
				if (tela[tela_linha][tela_coluna] == 1)
				{
														
					Cor(0xF4);	Sleep(10);
					VaiParaXY(tela_coluna, tela_linha);
					printf("\xDF");
				}
			}
		}
		
		break;
		//system("cls");
	}

}
int menu()


{

	int x;
	//tela_abertura();
	//Sleep(2000);
	system("cls");
	fflush(stdin);


	setlocale(LC_ALL, "");
	VaiParaXY(31, 3); printf("** Marcar consulta **");
	VaiParaXY(35, 10); printf("1-Cadastrar");
	VaiParaXY(35, 11); printf("2-Imprimir");
	VaiParaXY(35, 12); printf("3-Fim");
	VaiParaXY(35, 13); printf("4-Salvar");
	VaiParaXY(35, 14); printf("5-Carregar");
	VaiParaXY(35, 15); printf("6-Consultar");
	VaiParaXY(35, 16); printf("7-Exluir");
	VaiParaXY(35, 17); printf("8-Editar");
	VaiParaXY(31, 20); printf("Digite sua op��o:");
	VaiParaXY(52, 20); scanf_s("%d", &x);
	system("cls");
	return x;

}


void cadastra()
{
	int i, val = 0;
	char continua,continua2;
	for (i = 0; i < 4; i++)
	{
		if (agenda[i].flag == '0')
		{
			system("cls");
			VaiParaXY(36, 4); printf("CADASTRAR");
			VaiParaXY(20, 11); printf("Entre com a data atual: __/__/____");
			VaiParaXY(44, 11); scanf_s("%i", &agenda[i].dia);
			VaiParaXY(47, 11); scanf_s("%i", &agenda[i].mes);
			VaiParaXY(50, 11); scanf_s("%i", &agenda[i].ano);
			system("cls");
			VaiParaXY(36, 4); printf("CADASTRAR");
			VaiParaXY(6, 7); printf("Tecle <enter>para pr�ximo");
			VaiParaXY(20, 11); printf("Entre com o %d nome:", i + 1);
			VaiParaXY(20, 13); printf("Entre com o %d endere�o:", i + 1);
			VaiParaXY(20, 15); printf("Entre com o %d telefone:", i + 1);
			VaiParaXY(20, 17); printf("Entre com o %d celular:", i + 1);
			VaiParaXY(20, 19); printf("Entre com o %d convenio:", i + 1);
			VaiParaXY(20, 23); printf("<Para letras inserir 0 e n�o utilizar pontos e tra�os>");
			VaiParaXY(20, 21); printf("Entre com o %d email:", i + 1);
			VaiParaXY(20, 25); printf("Entre com o %d RG:", i + 1);
			VaiParaXY(20, 27); printf("Entre com o %d CPF:", i + 1);
			VaiParaXY(20, 29); printf("Entre com a %d data de nascimento: __/__/____", i + 1);

			VaiParaXY(20, 31); printf("Idade:     anos");
			fflush(stdin);
			VaiParaXY(46, 11); gets_s(agenda[i].nome);
			VaiParaXY(46, 13); gets_s(agenda[i].end);
			VaiParaXY(46, 15); gets_s(agenda[i].tel);
			VaiParaXY(46, 17); gets_s(agenda[i].cel);
			VaiParaXY(46, 19); gets_s(agenda[i].conv);
			VaiParaXY(46, 21); gets_s(agenda[i].email);
			VaiParaXY(46, 25); gets_s(agenda[i].rg);
			VaiParaXY(46, 27); gets_s(agenda[i].cpf);
			VaiParaXY(54, 29); scanf_s("%i", &agenda[i].dian);
			VaiParaXY(57, 29); scanf_s("%i", &agenda[i].mesn);
			VaiParaXY(60, 29); scanf_s("%i", &agenda[i].anon);
			agenda[i].id = ((agenda[i].dia + (agenda[i].mes * 30) + (agenda[i].ano * 365)) - (agenda[i].dian + (agenda[i].mesn * 30) + (agenda[i].anon * 365))) / 365;
			VaiParaXY(27, 31); printf("%d",agenda[i].id);
			agenda[i].flag = '1';
			
			
			
			
			
			VaiParaXY(20, 33); printf("Deseja fazer um or�amento? <S/N> ?");
			//VaiParaXY(45, 33);
			fflush(stdin);
			continua2 = getchar();
			if (continua2 == 's' || continua2 == 'S')
			{
				system("cls");

				char continua;

				printf("Quantas sess�es foram feitas de clareamento?(R$:650)");
				scanf_s("%i", &agenda[i].val_clareamento);
				printf("Quantas sess�es foram feitas de limpeza?(R$:100)");
				scanf_s("%i", &agenda[i].val_limpeza);
				printf("Quantas sess�es foram feitas de implante?(R$:800)");
				scanf_s("%i", &agenda[i].val_conta);

				agenda[i].id2 = (agenda[i].val_clareamento * 650) + (agenda[i].val_limpeza * 100) + (agenda[i].val_conta * 800);
				VaiParaXY(20, 15); printf("O valor total foi de %d:", agenda[i].id2);
				agenda[i].flag = '1';
				_getch();
				system("cls");

				VaiParaXY(15, 16);
				printf("Deseja continuar com o cadastro?<S/N> ");
				VaiParaXY(53, 16);
				fflush(stdin);

				continua = getchar();
				if (continua == 's' || continua == 'S')
				{
					system("cls");
					cadastra();


				}
				if (continua != 's' && continua != 'S')
				{
					system("cls");
					break;


				}
			}

			else
			{



				//_getch();
				system("cls");

				VaiParaXY(15, 16);
				printf("Deseja continuar com o cadastro?<S/N> ");
				VaiParaXY(53, 16);
				fflush(stdin);

				continua = getchar();
				if (continua == 's' || continua == 'S')
				{
					system("cls");
					cadastra();

				//	(continua != 's' && continua != 'S')
				}
				if (continua == 'n' || continua == 'N')
				{
					system("cls");
					break;


				}

			}

			
			
			
			
		
		}
		
else
		{
			val++;
			if (val > 2)
			{
				system("cls");
				VaiParaXY(30, 12);
				printf("agenda cheia!");
				_getch();
				system("cls");
				break;
			}
		}
	}
	ordena();
}
void imprimi()
{
	ordena();
	int a;
	system("cls");
	for (a = 0; a < 4; a++)//imprimi na tela
	{
		if (agenda[a].flag != '0')
		{
			VaiParaXY(12, 12); puts("Nome:");
			VaiParaXY(17, 12); puts(agenda[a].nome);
			VaiParaXY(12, 13); puts("Endereco:");
			VaiParaXY(22, 13); puts(agenda[a].end);
			VaiParaXY(12, 14); puts("Telefone:");
			VaiParaXY(22, 14); puts(agenda[a].tel);
			VaiParaXY(12, 15); puts("Celular:");
			VaiParaXY(22, 15); puts(agenda[a].cel);
			VaiParaXY(12, 16); puts("Conv�nio:");
			VaiParaXY(22, 16); puts(agenda[a].conv);
			VaiParaXY(12, 17); puts("Email:");
			VaiParaXY(20, 17); puts(agenda[a].email);
			VaiParaXY(12, 18); puts("RG:");
			VaiParaXY(17, 18); puts(agenda[a].rg);
			VaiParaXY(12, 19); puts("CPF:");
			VaiParaXY(17, 19); puts(agenda[a].cpf);
			VaiParaXY(12, 20); printf("%d anos", agenda[a].id);
			VaiParaXY(12, 21); printf("or�amento R$:%d ", agenda[a].id2);

			_getch();
			system("cls");
		}
	}
}
void ordena()
{
	int k, w;
	for (k = 0; k < 4 - 1; k++)
	{
		for (w = k + 1; w < 4; w++)
		{
			if (_strcmpi(agenda[k].nome, agenda[w].nome)>0)
			{
				aux = agenda[k];
				agenda[k] = agenda[w];
				agenda[w] = aux;
			}
		}
	}

}

void salvar()
{
	int j;
	FILE *tp;
	errno_t err;
	if ((err = fopen_s(&tp, "cadastro.txt", "w")) != NULL)
	{
		VaiParaXY(30, 18); printf("N�o foi possivel salvar o arquivo");
		_getch();
		exit(1);
	}
	else
	for (j = 0; j < 4; j++)
	{
		fwrite(&agenda[j], sizeof(agenda), 1, tp);
		fclose(tp);
	}
	system("cls");
	VaiParaXY(40, 20); printf("Salvo com sucesso!!");
	_getch();
	system("cls");

}
void carregar()
{

	FILE *tp;
	int j;
	errno_t err;
	if ((err = fopen_s(&tp, "cadastro.txt", "r")) != NULL)
	{
		VaiParaXY(30, 18); printf("Esse arquivo n�o existe!!!");
		_getch();
		exit(1);
	}
	else
	{
		for (j = 0; j < 4; j++)
		{
			fread(&agenda[j], sizeof(agenda), 1, tp);
			fclose(tp);
		}
		VaiParaXY(35, 18); printf("sucesso!!!");
		_getch();
		system("cls");
	}
}
void consultar()
{
	char nome[80], rg[9], cpf[11];
	char continua;
	int x, i, b, a;
	do
	{
		x = -1;
		VaiParaXY(36, 4); printf("Consultar");
		VaiParaXY(20, 11); printf("Deseja consultar por:");
		VaiParaXY(20, 12); printf("1-Nome");
		VaiParaXY(20, 13); printf("2-RG");
		VaiParaXY(20, 14); printf("3-CPF");
		VaiParaXY(50, 11); scanf_s("%i", &b);
		if (b == 1)
		{
			system("cls");
			VaiParaXY(32, 11); printf("Nome:");
			fflush(stdin);
			gets_s(nome);
			for (i = 0; i < 4; i++)
			if (_strcmpi(agenda[i].nome, nome) == 0)
				x = i;
			if (x == -1)
			{
				VaiParaXY(45, 20); printf("N�o encontrado!");
			}
			else
			{

				if (agenda[x].flag != '0')
				{
					VaiParaXY(12, 12); puts("Nome:");
					VaiParaXY(22, 12); puts(agenda[x].nome);
					VaiParaXY(12, 13); puts("Endereco:");
					VaiParaXY(22, 13); puts(agenda[x].end);
					VaiParaXY(12, 14); puts("Telefone:");
					VaiParaXY(22, 14); puts(agenda[x].tel);
					VaiParaXY(12, 15); puts("Celular:");
					VaiParaXY(22, 15); puts(agenda[x].cel);
					VaiParaXY(12, 16); puts("Conv�nio:");
					VaiParaXY(22, 16); puts(agenda[x].conv);
					VaiParaXY(12, 17); puts("Email:");
					VaiParaXY(22, 17); puts(agenda[x].email);
					VaiParaXY(12, 18); puts("RG:");
					VaiParaXY(22, 18); puts(agenda[x].rg);
					VaiParaXY(12, 19); puts("CPF:");
					VaiParaXY(22, 19); puts(agenda[x].cpf);
					VaiParaXY(12, 20); printf("Or�amento R$:%d ", agenda[x].id2);
					VaiParaXY(22, 21); printf("%d anos", agenda[x].id);

					_getch();
					system("cls");






				}
			}
		}
		if (b == 2)
		{
			system("cls");
			VaiParaXY(32, 11); printf("RG:");
			fflush(stdin);
			gets_s(rg);
			for (i = 0; i < 4; i++)
			if (_strcmpi(agenda[i].rg, rg) == 0)
				x = i;
			if (x == -1)
			{
				VaiParaXY(45, 20); printf("N�o encontrado!");
			}
			else
			{
				if (agenda[x].flag != '0')
				{
					VaiParaXY(12, 12); puts("Nome:");
					VaiParaXY(22, 12); puts(agenda[x].nome);
					VaiParaXY(12, 13); puts("Endereco:");
					VaiParaXY(22, 13); puts(agenda[x].end);
					VaiParaXY(12, 14); puts("Telefone:");
					VaiParaXY(22, 14); puts(agenda[x].tel);
					VaiParaXY(12, 15); puts("Celular:");
					VaiParaXY(22, 15); puts(agenda[x].cel);
					VaiParaXY(12, 16); puts("Conv�nio:");
					VaiParaXY(22, 16); puts(agenda[x].conv);
					VaiParaXY(12, 17); puts("Email:");
					VaiParaXY(22, 17); puts(agenda[x].email);
					VaiParaXY(12, 18); puts("RG:");
					VaiParaXY(22, 18); puts(agenda[x].rg);
					VaiParaXY(12, 19); puts("CPF:");
					VaiParaXY(22, 19); puts(agenda[x].cpf);
					VaiParaXY(12, 20); printf("Or�amento R$:%d ", agenda[x].id2);
					VaiParaXY(22, 21); printf("%d anos", agenda[x].id);

					_getch();
					system("cls");






				}
			}
		}
		if (b == 3)
		{
			system("cls");
			VaiParaXY(32, 11); printf("CPF:");
			fflush(stdin);
			gets_s(cpf);
			for (i = 0; i < 4; i++)
			if (_strcmpi(agenda[i].cpf, cpf) == 0)
				x = i;
			if (x == -1)
			{
				VaiParaXY(45, 20); printf("N�o encontrado!");
			}
			else
			{
				if (agenda[x].flag != '0')
				{
					VaiParaXY(12, 12); puts("Nome:");
					VaiParaXY(22, 12); puts(agenda[x].nome);
					VaiParaXY(12, 13); puts("Endereco:");
					VaiParaXY(22, 13); puts(agenda[x].end);
					VaiParaXY(12, 14); puts("Telefone:");
					VaiParaXY(22, 14); puts(agenda[x].tel);
					VaiParaXY(12, 15); puts("Celular:");
					VaiParaXY(22, 15); puts(agenda[x].cel);
					VaiParaXY(12, 16); puts("Conv�nio:");
					VaiParaXY(22, 16); puts(agenda[x].conv);
					VaiParaXY(12, 17); puts("Email:");
					VaiParaXY(22, 17); puts(agenda[x].email);
					VaiParaXY(12, 18); puts("RG:");
					VaiParaXY(22, 18); puts(agenda[x].rg);
					VaiParaXY(12, 19); puts("CPF:");
					VaiParaXY(22, 19); puts(agenda[x].cpf);
					VaiParaXY(12, 20); printf("Or�amento R$:%d ", agenda[x].id2);
					VaiParaXY(22, 21); printf("%d anos", agenda[x].id);

					_getch();
					system("cls");






				}
			}
		}

		VaiParaXY(52, 18); printf("Deseja continuar com a consulta? (S/N):");
		fflush(stdin);
		continua = getchar();
		system("cls");
		if (continua == 'n' || continua == 'N')
		{
			system("cls");
			break;
		}



	}


	while (continua == 'S' || 's');
}

	


void excluir()
{
	char nome[80];
	char continua, letraexcl;
	int i, x;
	{
		system("cls");
		x = -1;
		VaiParaXY(30, 4); printf("Exluir");
		VaiParaXY(20, 11); printf("Nome:");
		fflush(stdin);
		gets_s(nome);
		for (i = 0; i < 4; i++)
		{
			if (_strcmpi(agenda[i].nome, nome) == 0)
			{
				x = i;
			}
		}
		if (x == -1)
		{
			VaiParaXY(45, 20); printf("N�o encontrado");
		}
		else
		{
		


			if (agenda[x].flag != '0')
			{
				VaiParaXY(12, 12); puts("Nome:");
				VaiParaXY(22, 12); puts(agenda[x].nome);
				VaiParaXY(12, 13); puts("Endereco:");
				VaiParaXY(22, 13); puts(agenda[x].end);
				VaiParaXY(12, 14); puts("Telefone:");
				VaiParaXY(22, 14); puts(agenda[x].tel);
				VaiParaXY(12, 15); puts("Celular:");
				VaiParaXY(22, 15); puts(agenda[x].cel);
				VaiParaXY(12, 16); puts("Conv�nio:");
				VaiParaXY(22, 16); puts(agenda[x].conv);
				VaiParaXY(12, 17); puts("Email:");
				VaiParaXY(22, 17); puts(agenda[x].email);
				VaiParaXY(12, 18); puts("RG:");
				VaiParaXY(22, 18); puts(agenda[x].rg);
				VaiParaXY(12, 19); puts("CPF:");
				VaiParaXY(22, 19); puts(agenda[x].cpf);
				VaiParaXY(12, 20); printf("Or�amento R$:%d ", agenda[x].id2);
				VaiParaXY(22, 21); printf("%d anos", agenda[x].id);

				_getch();
				system("cls");

								
			}
			exclus�o.flag = '0';
			agenda[x] = exclus�o;

			fflush(stdin);
			VaiParaXY(30, 18); printf("Deseja salvar a exlus�o? (s/n)");
		
			letraexcl = getchar();
			if (letraexcl == 's' || letraexcl == 'S')
			{
				salvar();
			}
			else
			{
				menu();
			}
		}
		VaiParaXY(52, 24); printf("continuar? (s/n)");
		continua = getchar();
		if (continua == 's' || continua == 'S')
		{
			excluir();
		}
		else
		{
			menu();
		}
	} 
	system("cls");
}
void fim()
{
	int val;
	system("cls");
	VaiParaXY(12, 13); printf("Voc� deseja salvar os dados?");
	VaiParaXY(12, 14); printf(" Sim (1), se N�o (9):");
	scanf_s("%i", &val);
	if (val == 1)
	{
		salvar();
		system("CLS");
		exit(1);
	}
	if (val == 9)
	{
		
		
		exit(1);
	}
}
void editar()
{
	char nome[80];
	
	int x, i, edit;
	x = -1;
	VaiParaXY(36, 4); printf("Editar");
	VaiParaXY(20, 11); printf("Nome:");
	fflush(stdin);
	gets_s(nome);
	for (i = 0; i < 4; i++)

	{
		if (_strcmpi(agenda[i].nome, nome) == 0)
		{
			x = i;
			fflush(stdin);
			system("cls");
			VaiParaXY(12, 10); puts("Voc� ir� editar o seguinte us�ario:");
			VaiParaXY(12, 12); puts("Nome:");
			VaiParaXY(17, 12); puts(agenda[x].nome);
			VaiParaXY(12, 13); puts("Endereco:");
			VaiParaXY(22, 13); puts(agenda[x].end);
			VaiParaXY(12, 14); puts("Telefone:");
			VaiParaXY(22, 14); puts(agenda[x].tel);
			VaiParaXY(12, 15); puts("Celular:");
			VaiParaXY(22, 15); puts(agenda[x].cel);
			VaiParaXY(12, 16); puts("Conv�nio:");
			VaiParaXY(22, 16); puts(agenda[x].conv);
			VaiParaXY(12, 17); puts("Email:");
			VaiParaXY(20, 17); puts(agenda[x].email);
			VaiParaXY(12, 18); puts("RG:");
			VaiParaXY(17, 18); puts(agenda[x].rg);
			VaiParaXY(12, 19); puts("CPF:");
			VaiParaXY(17, 19); puts(agenda[x].cpf);
			VaiParaXY(12, 20); printf("%d anos", agenda[x].id);
			VaiParaXY(12, 21); printf("or�amento R$:%d ", agenda[x].id2);

			_getch();
			system("cls");





			VaiParaXY(33, 20); printf("Deseja editar o usu�rio? <S/N>");
			edit = getchar();
			if (edit == 's' || edit == 'S')
			{
				system("cls");
				edita.flag = 0;
				agenda[x] = edita;
				VaiParaXY(10, 10); printf("Entre novamente com a data atual: __/__/____");
				VaiParaXY(44, 10); scanf_s("%i", &agenda[i].dia);
				VaiParaXY(47, 10); scanf_s("%i", &agenda[i].mes);
				VaiParaXY(50, 10); scanf_s("%i", &agenda[i].ano);
				system("cls");
				VaiParaXY(6, 7); printf("Tecle <enter>para pr�ximo");
				VaiParaXY(20, 11); printf("Entre com o novo nome:");
				VaiParaXY(20, 13); printf("Entre com o novo endere�o:");
				VaiParaXY(20, 15); printf("Entre com o novo telefone:");
				VaiParaXY(20, 17); printf("Entre com o novo celular:");
				VaiParaXY(20, 19); printf("Entre com o novo convenio:");
				VaiParaXY(20, 21); printf("Entre com o novo email:");
				VaiParaXY(20, 23); printf("Entre com o novo RG:");
				VaiParaXY(20, 25); printf("Entre com o novo CPF:");
				VaiParaXY(12, 29); printf("Entre novamente com a data de nascimento: __/__/____", i + 1);
				
				VaiParaXY(20, 31); printf("Idade:     anos");
				fflush(stdin);
				VaiParaXY(46, 11); gets_s(agenda[i].nome);
				VaiParaXY(46, 13); gets_s(agenda[i].end);
				VaiParaXY(46, 15); gets_s(agenda[i].tel);
				VaiParaXY(46, 17); gets_s(agenda[i].cel);
				VaiParaXY(46, 19); gets_s(agenda[i].conv);
				VaiParaXY(46, 21); gets_s(agenda[i].email);
				VaiParaXY(46, 23); gets_s(agenda[i].rg);
				VaiParaXY(46, 25); gets_s(agenda[i].cpf);
				VaiParaXY(54, 29); scanf_s("%i", &agenda[i].dian);
				VaiParaXY(57, 29); scanf_s("%i", &agenda[i].mesn);
				VaiParaXY(60, 29); scanf_s("%i", &agenda[i].anon);
				agenda[i].id = ((agenda[i].dia + (agenda[i].mes * 30) + (agenda[i].ano * 365)) - (agenda[i].dian + (agenda[i].mesn * 30) + (agenda[i].anon * 365))) / 365;
				VaiParaXY(27, 31); printf("%d", agenda[i].id);
				agenda[i].flag = '1';
				_getch();
				system("cls");
				VaiParaXY(40, 20); printf("Salvo com sucesso!!");
				system("cls");
				salvar();
				


				VaiParaXY(5, 10); printf("Deseja refazer um  novo or�amento? <S/N> ?");
				//VaiParaXY(45, 33);
				fflush(stdin);
				char continua2 = getchar();
				if (continua2 == 's' || continua2 == 'S')
				{
					system("cls");


					printf("Quantas sess�es foram feitas de clareamento?(R$:650)");
					scanf_s("%i", &agenda[i].val_clareamento);
					printf("Quantas sess�es foram feitas de limpeza(R$:100)?");
					scanf_s("%i", &agenda[i].val_limpeza);
					printf("Quantas sess�es foram feitas de implante(R$:800)?");
					scanf_s("%i", &agenda[i].val_conta);

					agenda[i].id2 = (agenda[i].val_clareamento * 650) + (agenda[i].val_limpeza * 100) + (agenda[i].val_conta * 800);
					VaiParaXY(20, 15); printf("O valor total foi de %d:", agenda[i].id2);
					agenda[i].flag = '1';
					_getch();
					system("cls");


				}


			}
			if (edit == 'n' || edit == 'N')
			{
				system("cls");
				menu();
			}

			if (x == -1)
			{
				VaiParaXY(45, 20); printf("N�o encontrado!");
				system("cls");
				menu();
			}
		}
	}

}